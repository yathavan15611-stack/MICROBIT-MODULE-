SINGLE-FILE YATHAVAN TECH WEBSITE

All pictures are embedded inside index.html itself. There is no assets folder to upload.
The WhatsApp order link is configured. Buttons open a prefilled message for the customer to review and send.
